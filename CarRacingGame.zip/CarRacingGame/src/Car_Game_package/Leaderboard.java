package Car_Game_package;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import Car_Game_package.User_name;


public class Leaderboard extends JFrame {

    private JPanel contentPane;
    private JTable table;
    private JScrollPane scrollPane;
    private JTable tblData;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Leaderboard frame = new Leaderboard();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Leaderboard() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 691, 730);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(102, 205, 170));
        contentPane.setForeground(Color.BLACK);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        JButton btnShow = new JButton("SEE");
        btnShow.setBackground(new Color(255, 69, 0));
        btnShow.setFont(new Font("Lucida Fax", Font.BOLD, 19));
        btnShow.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Class.forName("com.mysql.jdbc.Driver");
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Car_game", "root", "#LegionY540");
                    Statement st = con.createStatement();
                    String query = "select * from Leaderboard ORDER BY Score DESC;";
                    ResultSet rs = st.executeQuery(query);

                    ResultSetMetaData rsmd = rs.getMetaData();
                    DefaultTableModel model = new DefaultTableModel();

                    int cols = rsmd.getColumnCount();
                    for (int i = 1; i <= cols; i++) {
                        model.addColumn(rsmd.getColumnName(i));
                    }

                    while (rs.next()) {
                        Object[] row = new Object[cols];
                        for (int i = 1; i <= cols; i++) {
                            row[i - 1] = rs.getObject(i);
                        }
                        model.addRow(row);
                    }

                    tblData.setModel(model);
                } catch (ClassNotFoundException | SQLException e1) {
                    e1.printStackTrace();
                }
            }
        });

        JLabel lblNewLabel = new JLabel("LEADERBOARD");
        lblNewLabel.setFont(new Font("Jokerman", Font.BOLD, 30));
        lblNewLabel.setBounds(206, 30, 282, 38);
        contentPane.add(lblNewLabel);

        scrollPane = new JScrollPane();
        scrollPane.setBounds(61, 78, 567, 521);
        contentPane.add(scrollPane);

        tblData = new JTable();
        scrollPane.setViewportView(tblData);

        btnShow.setBounds(277, 619, 139, 43);
        contentPane.add(btnShow);
    }
}
