package Car_Game_package;

public class Main
{
	public static void main(String args[])
	{
		CarGame myGame =new CarGame("CarRacingGame",1);
		
		
		
	}
}
 	
