package Car_Game_package;
import java.sql.*;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.DropMode;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Statement;

import javax.swing.UIManager;
import javax.swing.JDesktopPane;

public class User_name extends JFrame {

	private JPanel contentPane;
	private JTextField PLAYER_NAME;
	private JButton Enter;
	private JButton Reset;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					User_name frame = new User_name();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public User_name() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 649, 478);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 204, 153));
		contentPane.setForeground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		PLAYER_NAME = new JTextField();
		PLAYER_NAME.setBackground(new Color(255, 255, 204));
		PLAYER_NAME.setBounds(275, 172, 329, 37);
		PLAYER_NAME.setFont(new Font("Tahoma", Font.BOLD, 25));
		PLAYER_NAME.setHorizontalAlignment(SwingConstants.LEFT);
		contentPane.add(PLAYER_NAME);
		PLAYER_NAME.setColumns(10);
		
		Enter = new JButton("ENTER");
		Enter.setBounds(365, 280, 146, 33);
		Enter.setBackground(new Color(0, 255, 255));
		Enter.setFont(new Font("Tahoma", Font.BOLD, 20));
		contentPane.add(Enter);
		
		JLabel lblNewLabel = new JLabel("USER NAME");
		lblNewLabel.setBounds(48, 156, 187, 68);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 25));
		contentPane.add(lblNewLabel);
		
		 Reset = new JButton("RESET");
	        Reset.setForeground(Color.BLACK);
	        Reset.setFont(new Font("Tahoma", Font.BOLD, 20));
	        Reset.setBackground(new Color(0, 255, 255));
	        Reset.setBounds(113, 280, 146, 33);
	        contentPane.add(Reset);

	        // ActionListener for Enter button
	        Enter.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	            	String playerName = PLAYER_NAME.getText();
	            	String player1= playerName;
	                // Check if the player name is null or empty
	                if (playerName == null || playerName.trim().isEmpty()) {
	                    // Show a warning message
	                    JOptionPane.showMessageDialog(User_name.this, "Please enter a valid player name", "Warning", JOptionPane.WARNING_MESSAGE);
	                } else {
	                	CarGame car = new CarGame(player1);
	                    Main.main(null);
	                    dispose();
	                }// Add code for the Enter button action if needed
	            }
	        });

	        // ActionListener for Reset button
	        Reset.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	                // Resetting the text of the PLAYER_NAME JTextField
	                PLAYER_NAME.setText("");
	            }
	        });

		
		JLabel lblNewLabel_1 = new JLabel(":-");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_1.setBounds(220, 184, 45, 13);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Unleash the Speed: Race to Dominate!");
		lblNewLabel_2.setFont(new Font("Jokerman", Font.BOLD, 26));
		lblNewLabel_2.setBounds(75, 25, 498, 108);
		contentPane.add(lblNewLabel_2);
		
		JDesktopPane desktopPane = new JDesktopPane();
		desktopPane.setBounds(124, 499, 86, -102);
		contentPane.add(desktopPane);
	}
}
